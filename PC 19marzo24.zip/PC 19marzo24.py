#Este programa muestra el dia, mes y año actual
from datetime import date
print(date.today())
print()
today=(date.today()).day
todaymonth=(date.today()).month
todayear=(date.today()).year
print("Ingrese su fecha de nacimiento")
day=int(input("dia:"))
month=int(input("month:"))
year=int(input("year:"))
print ("La fecha actual es: "today, "-",todaymonth "-") )
